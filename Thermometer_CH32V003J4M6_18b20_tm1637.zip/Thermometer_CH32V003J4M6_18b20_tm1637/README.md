**Thermometer with CH32V003J4M6 and DS18b20**

For one DS18B20 sensor
- DS18B20 - Connection to PA2
- LED - Connection to PC4
- Temperature output to UART
- Temperature output to TM1637


*** <br>
Pin selection in main.h <br>
Frequency 24/48 MHz <br>

_______________________________________________

**Термомерт на CH32V003J4M6 и DS18b20**

Для одного датчика DS18B20
- DS18B20 - Подключение к PA2
- LED - Подключение к PC4
- Вывод температуры в UART
- Вывод температуры на ТМ1637

 \*** <br> 
 Выбор пинов в main.h <br>
 Частота 24/48 МГц <br>
