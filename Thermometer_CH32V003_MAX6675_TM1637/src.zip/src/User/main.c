// MAX6675 temperature reader for WCH CH32V003 (24Mhz)

#include "tm1637.h"
#include "debug.h"
#include "string.h"
#include "ch32v00x_iwdg.h"
#include "adc_vref.h"

// pins connect MAX6675
#define MAX6675_SO         GPIO_Pin_1
#define MAX6675_SO_Port    GPIOA
#define MAX6675_SCK        GPIO_Pin_2
#define MAX6675_SCK_Port   GPIOA
#define MAX6675_CS         GPIO_Pin_4
#define MAX6675_CS_Port    GPIOC

#define VREF_COEF  1227600UL // 1200 * 1023 = 1227600. 1200(mV)-Vref_in
#define BATTERY_LOW   3200   // 3200 mV - Battery discharge threshold Li-ion

uint16_t temp = 0;      // temperature
uint16_t raw_temp = 0;  // temperature without filtration
uint8_t line_break = 0; // line break

void max6675_read(void);

int main(void) {
  SystemCoreClockUpdate();
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
  Delay_Init();

  // Enable clocking GPIOA � GPIOC
  GPIO_InitTypeDef GPIO_InitStructure = {0};
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

  // Configuring MAX6675_CS as push-pull output
  GPIO_InitStructure.GPIO_Pin = MAX6675_CS;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_30MHz;
  GPIO_Init(MAX6675_CS_Port, &GPIO_InitStructure);

  // Configuring MAX6675_SCK as push-pull output
  GPIO_InitStructure.GPIO_Pin = MAX6675_SCK;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_30MHz;
  GPIO_Init(MAX6675_SCK_Port, &GPIO_InitStructure);

  // Configuring MAX6675_SO as input (without lifting)
  GPIO_InitStructure.GPIO_Pin = MAX6675_SO;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_Init(MAX6675_SO_Port, &GPIO_InitStructure);
  
  // Initial state SPI line MAX6675
  GPIO_SetBits(MAX6675_CS_Port, MAX6675_CS);     // CS = 1 (not active)
  GPIO_ResetBits(MAX6675_SCK_Port, MAX6675_SCK); // SCK = 0

  // Initialization ADC
  ADCVREF_Init();
  Delay_Ms(100);
  
  TM1637_Init();
  TM1637_SetBrightness(3);    // bright 0-7
  uint8_t LED[4] = {1,2,3,4}; // set the display value
  uint8_t dp = 0;             // 1-the point is on
  uint8_t znak = 0;           // mark
  uint16_t val;

  // Setting IWDG = ~1 s
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  IWDG_SetPrescaler(IWDG_Prescaler_128); // PR = 128
  IWDG_SetReload(1000);                  // RLR = 1000
  IWDG_ReloadCounter();
  IWDG_Enable();

  while (1) {
    IWDG_ReloadCounter(); //reset Watchdog
    
    // Determining the battery charge Li-ion (Vdd)
    uint16_t vref = ADCVREF_GetVref(); // Read Vref
    uint16_t vdd = VREF_COEF / vref;   // Find Vdd (mV)
    
    // Reading the temperature
    max6675_read();

    if (line_break) 
    { 
      // line break
      znak = 1; 
    }
    else
      znak = 0;

    // TM1637 display, divide into digits
    val = temp;
    LED[0] = val / 100;
    LED[1] = (val / 10) % 10;
    LED[2] = val % 10;
    if (LED[0]==0) LED[0] = 10; //disable the first 0

    // Output sign in LED[3]
    if (znak)
    {
      LED[0] = 11; // output sign "-"
      LED[1] = 11; // output sign "-"
      LED[2] = 11; // output sign "-"
      LED[3] = 11; // output sign "-"
    }
    else
      LED[3] = 14; // Degree Celsius sign output
      
    if (vdd < BATTERY_LOW)
      LED[3] = 23; // output  sign "L"

    // Loading data into the display
    for (int i = 0; i < 4; i++)
      {
      TM1637_DisplayDigit(i, LED[i], (i == 1 && dp));
      } 

    Delay_Ms(500); // not less than 220 mC
  }
}
 

//******************************************** MAX6675 *********************************************
// declare global variables: uint16_t temp = 0; uint16_t raw_temp = 0; uint8_t line_break = 0;
void max6675_read(void)
{
	// static uint8_t first = 1;
  static uint8_t first = 2; // We skip 2 measurements (���������� 2 ������ ������ 1, ��� ��� ������ ����� ������)
  uint16_t data = 0;
  // set CS to low level - start reading.
  // The SPI polling rate is approximately 500 kHz. The entire polling process takes approximately 35 �s.
  GPIO_ResetBits(MAX6675_CS_Port, MAX6675_CS);
  Delay_Us(1);

  for (uint8_t i = 0; i < 16; i++)
  {
    // Set SCK = 1
    GPIO_SetBits(MAX6675_SCK_Port, MAX6675_SCK);
    data <<= 1;
    Delay_Us(1); // or __NOP(); __NOP(); to increase the polling speed

    // read data
    uint8_t state = GPIO_ReadInputDataBit(MAX6675_SCK_Port, MAX6675_SO);
    if (state)
      data |= 1;
    
    // Set SCK = 0
    GPIO_ResetBits(MAX6675_SCK_Port, MAX6675_SCK);
    Delay_Us(1);
  }

  // set CS high - end of reading
  GPIO_SetBits(MAX6675_CS_Port, MAX6675_CS);

  // checking for a break (2nd bit = 1)
  if (data & (1 << 2)) // or (data & 0x4)
  {
    line_break = 1; // Thermocouple is not connected or open
    first = 1;      // reset filter
    temp = 0;
    return; 
  }
  line_break = 0;

  // get the temperature
  uint16_t new_temp = data >> 5;  // integer, without a point
  raw_temp = new_temp;  // temperature without filtration

  if (first)
  {
    // Disabling the EMA filter for the first measurements
    temp = new_temp;
    first--;  
  }
  else
  {
    // EMA filter
    temp = temp - ((temp - new_temp) >> 1);  // light and fast filter
    // temp = temp - ((temp - new_temp + 2) >> 2); // filtration is stronger but a little slower
  }
}




/*

// ***** EMA ������ *****
temp = temp - ((temp - new_temp) >> 1);  // ������ � ������� ������
// temp = temp - ((temp - new_temp + 2) >> 2); // ���������� ������� �� ������� ���������

// ***** ����� ������ ������ � "��������" *****
int diff = new_temp - temp;
temp += (diff >> 2);
if (diff != 0 && (diff > 0 ? diff < 4 : diff > -4)) {
    temp = new_temp;
}

// ����� ����������� � ��������
// printf("Temp: %d oC\n\r", temp);
printf("Temp: %d [%d] \n\r", raw_temp, temp);
// printf("Temp: %d.%02d oC\n\r",  (int)temp, (int)(temp*100) % 100);

*/