#ifndef _ADC_VREF_H_
#define _ADC_VREF_H_

#include "debug.h"

void ADCVREF_Init(void);
uint16_t ADCVREF_GetVref(void);
uint16_t ADCVREF_ReadChannel(uint8_t ch);

#endif // _ADC_VREF_H_
