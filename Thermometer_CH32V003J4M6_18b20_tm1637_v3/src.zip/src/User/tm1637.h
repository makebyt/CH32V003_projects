
#ifndef TM1637_H
#define TM1637_H

#include <stdint.h>

// Выбор Нормальных или Перевёрнутых символов
#define ROTATE 1  // 0 - неперевёрнутые символы

// Определяем пины для подключения
#define TM1637_CLK_PORT GPIOC       // CLK port
#define TM1637_DIO_PORT GPIOC       // DIO port
#define TM1637_CLK_PIN  GPIO_Pin_1  // CLK pin
#define TM1637_DIO_PIN  GPIO_Pin_2  // DIO pin

void TM1637_Init(void);
void TM1637_SetBrightness(uint8_t level);
void TM1637_DisplayDigit(uint8_t pos, uint8_t value, uint8_t dot);
void TM1637_DisplayOff(void);

#endif
 